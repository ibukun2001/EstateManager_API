from django.urls import path

from .views import PlotListCreateView,PlotDetailView


urlpatterns=[
    path("",PlotListCreateView.as_view()),
    path("<int:id>/",PlotDetailView.as_view()),
]