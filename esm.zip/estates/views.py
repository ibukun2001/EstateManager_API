from django.shortcuts import render

# Create your views here.
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated

from .models import Estate
from .serializers import EstateSerializer


class EstateListCreateView(APIView):

    permission_classes=[
        IsAuthenticated
    ]


    def get(self,request):

        estates=Estate.objects.filter(
            company=request.user.company
        )

        serializer=EstateSerializer(
            estates,
            many=True
        )

        return Response(
            serializer.data
        )


    def post(self,request):
        serializer=EstateSerializer(
            data=request.data
        )
        if serializer.is_valid():
            serializer.save(
                company=request.user.company
            )
            return Response(
                serializer.data,
                status=201
            )
        return Response(
            serializer.errors,
            status=400
        )


class CompanyDashboardView(APIView):
    permission_classes=[
        IsAuthenticated
    ]
    def get(self,request):
        company=request.user.company
        estates=Estate.objects.filter(
            company=company
        )
        estate_data=[]
        for estate in estates:
            estate_data.append({
                "id":estate.id,
                "name":estate.name,
                "location":estate.location,
                "total":0,
                "available":0,
                "sold":0
            })
        return Response({
            "company":company.name,
            "kpis":[
                {
                    "title":"Total Estates",
                    "value":estates.count(),
                    "color":"#2563eb"
                },
                {
                    "title":"Total Plots",
                    "value":0,
                    "color":"#2563eb"
                },
                {
                    "title":"Available Plots",
                    "value":0,
                    "color":"#16a34a"
                },
                {
                    "title":"Sold Plots",
                    "value":0,
                    "color":"#dc2626"
                }
            ],
            "estates":estate_data,

            "activities":[]
        })