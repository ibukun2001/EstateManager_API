from django.urls import path
from .views import EstateListCreateView,CompanyDashboardView


urlpatterns=[
    path("",EstateListCreateView.as_view()),
    path("dashboard/",CompanyDashboardView.as_view())
]